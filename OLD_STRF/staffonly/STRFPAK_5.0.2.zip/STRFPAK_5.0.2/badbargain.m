function out = badbargain(a)
pause(a/10);
out = ones(1500);
