function out = get_strfpak_version;
out = 'Version 4.1 - experimental';
