function out = get_local_cache_dir
global outputPath
out = fullfile(outputPath,'local_cache_dir');