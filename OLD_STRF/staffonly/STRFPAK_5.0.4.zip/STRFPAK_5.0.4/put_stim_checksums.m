function out = put_stim_checksums(hashes_of_stims,DS);
global outputPath
rec_make_dir(fullfile(outputPath,'stim_hashes'));
for ii = 1:length(DS)
    dsname = DS{ii}.stimfiles;
    slashes = findstr(dsname,filesep);
    slashes = [0 slashes];
    dsname = dsname((slashes(end)+1):end);
    filename = fullfile(outputPath,'stim_hashes',dsname);
    if ~exist(filename,'file')
        this_hash = hashes_of_stims{ii};
        save(filename,'this_hash');
    end
end
