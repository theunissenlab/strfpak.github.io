function out = okbargain(a)
pause(a/10);
out = ones(500);
