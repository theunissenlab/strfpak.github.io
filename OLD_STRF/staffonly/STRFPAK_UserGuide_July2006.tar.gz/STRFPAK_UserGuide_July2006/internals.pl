# LaTeX2HTML 2002 (1.62)
# Associate internals original text with physical files.


$key = q/cca/;
$ref_files{$key} = "$dir".q|node43.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_jones/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_fet2/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/copyright/;
$ref_files{$key} = "$dir".q|node14.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_nandini/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_auger/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_jackknifed/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/displaypsth-2/;
$ref_files{$key} = "$dir".q|node40.html|; 
$noresave{$key} = "$nosave";

$key = q/strfa_3/;
$ref_files{$key} = "$dir".q|node34.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_dayan/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_svd1/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/askpred/;
$ref_files{$key} = "$dir".q|node38.html|; 
$noresave{$key} = "$nosave";

$key = q/main/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/modspectrum/;
$ref_files{$key} = "$dir".q|node33.html|; 
$noresave{$key} = "$nosave";

$key = q/predndisplay/;
$ref_files{$key} = "$dir".q|node48.html|; 
$noresave{$key} = "$nosave";

$key = q/displaypreprocess/;
$ref_files{$key} = "$dir".q|node30.html|; 
$noresave{$key} = "$nosave";

$key = q/strfa_2/;
$ref_files{$key} = "$dir".q|node34.html|; 
$noresave{$key} = "$nosave";

$key = q/goodnessfilterwidth/;
$ref_files{$key} = "$dir".q|node42.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_fet1/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_hsu1/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_lyngby/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ringach/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/displaypsth/;
$ref_files{$key} = "$dir".q|node40.html|; 
$noresave{$key} = "$nosave";

$key = q/displayinputGUI/;
$ref_files{$key} = "$dir".q|node19.html|; 
$noresave{$key} = "$nosave";

$key = q/preprocessmenu/;
$ref_files{$key} = "$dir".q|node22.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_mm/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/strfa/;
$ref_files{$key} = "$dir".q|node34.html|; 
$noresave{$key} = "$nosave";

$key = q/displaystrfv/;
$ref_files{$key} = "$dir".q|node34.html|; 
$noresave{$key} = "$nosave";

$key = q/infortol/;
$ref_files{$key} = "$dir".q|node43.html|; 
$noresave{$key} = "$nosave";

$key = q/loadstimonly/;
$ref_files{$key} = "$dir".q|node47.html|; 
$noresave{$key} = "$nosave";

$key = q/infoa/;
$ref_files{$key} = "$dir".q|node43.html|; 
$noresave{$key} = "$nosave";

$key = q/displaybeststrfall/;
$ref_files{$key} = "$dir".q|node46.html|; 
$noresave{$key} = "$nosave";

$key = q/spectrogramfig/;
$ref_files{$key} = "$dir".q|node25.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ryan/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/loadfile/;
$ref_files{$key} = "$dir".q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/calculationGUI/;
$ref_files{$key} = "$dir".q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/movielinear/;
$ref_files{$key} = "$dir".q|node27.html|; 
$noresave{$key} = "$nosave";

$key = q/displayraw/;
$ref_files{$key} = "$dir".q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/displayraw2/;
$ref_files{$key} = "$dir".q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_klein/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_junli/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/waveletfig/;
$ref_files{$key} = "$dir".q|node26.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_willmore/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/bestornot/;
$ref_files{$key} = "$dir".q|node48.html|; 
$noresave{$key} = "$nosave";

$key = q/moviepfft/;
$ref_files{$key} = "$dir".q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/cache/;
$ref_files{$key} = "$dir".q|node50.html|; 
$noresave{$key} = "$nosave";

$key = q/displaybeststrf/;
$ref_files{$key} = "$dir".q|node46.html|; 
$noresave{$key} = "$nosave";

1;

