# LaTeX2HTML 2002 (1.62)
# Associate labels original text with physical files.


$key = q/cca/;
$external_labels{$key} = "$URL/" . q|node43.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_jones/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_fet2/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/copyright/;
$external_labels{$key} = "$URL/" . q|node14.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_nandini/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_auger/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_jackknifed/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/displaypsth-2/;
$external_labels{$key} = "$URL/" . q|node40.html|; 
$noresave{$key} = "$nosave";

$key = q/strfa_3/;
$external_labels{$key} = "$URL/" . q|node34.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_dayan/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_svd1/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/askpred/;
$external_labels{$key} = "$URL/" . q|node38.html|; 
$noresave{$key} = "$nosave";

$key = q/main/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/modspectrum/;
$external_labels{$key} = "$URL/" . q|node33.html|; 
$noresave{$key} = "$nosave";

$key = q/predndisplay/;
$external_labels{$key} = "$URL/" . q|node48.html|; 
$noresave{$key} = "$nosave";

$key = q/displaypreprocess/;
$external_labels{$key} = "$URL/" . q|node30.html|; 
$noresave{$key} = "$nosave";

$key = q/strfa_2/;
$external_labels{$key} = "$URL/" . q|node34.html|; 
$noresave{$key} = "$nosave";

$key = q/goodnessfilterwidth/;
$external_labels{$key} = "$URL/" . q|node42.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_fet1/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_hsu1/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_lyngby/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ringach/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/displaypsth/;
$external_labels{$key} = "$URL/" . q|node40.html|; 
$noresave{$key} = "$nosave";

$key = q/displayinputGUI/;
$external_labels{$key} = "$URL/" . q|node19.html|; 
$noresave{$key} = "$nosave";

$key = q/preprocessmenu/;
$external_labels{$key} = "$URL/" . q|node22.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_mm/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/strfa/;
$external_labels{$key} = "$URL/" . q|node34.html|; 
$noresave{$key} = "$nosave";

$key = q/displaystrfv/;
$external_labels{$key} = "$URL/" . q|node34.html|; 
$noresave{$key} = "$nosave";

$key = q/infortol/;
$external_labels{$key} = "$URL/" . q|node43.html|; 
$noresave{$key} = "$nosave";

$key = q/loadstimonly/;
$external_labels{$key} = "$URL/" . q|node47.html|; 
$noresave{$key} = "$nosave";

$key = q/infoa/;
$external_labels{$key} = "$URL/" . q|node43.html|; 
$noresave{$key} = "$nosave";

$key = q/displaybeststrfall/;
$external_labels{$key} = "$URL/" . q|node46.html|; 
$noresave{$key} = "$nosave";

$key = q/spectrogramfig/;
$external_labels{$key} = "$URL/" . q|node25.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ryan/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/loadfile/;
$external_labels{$key} = "$URL/" . q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/calculationGUI/;
$external_labels{$key} = "$URL/" . q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/movielinear/;
$external_labels{$key} = "$URL/" . q|node27.html|; 
$noresave{$key} = "$nosave";

$key = q/displayraw/;
$external_labels{$key} = "$URL/" . q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/displayraw2/;
$external_labels{$key} = "$URL/" . q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_klein/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_junli/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/waveletfig/;
$external_labels{$key} = "$URL/" . q|node26.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_willmore/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/bestornot/;
$external_labels{$key} = "$URL/" . q|node48.html|; 
$noresave{$key} = "$nosave";

$key = q/moviepfft/;
$external_labels{$key} = "$URL/" . q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/cache/;
$external_labels{$key} = "$URL/" . q|node50.html|; 
$noresave{$key} = "$nosave";

$key = q/displaybeststrf/;
$external_labels{$key} = "$URL/" . q|node46.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2002 (1.62)
# labels from external_latex_labels array.


$key = q/displaypsth/;
$external_latex_labels{$key} = q|3.20|; 
$noresave{$key} = "$nosave";

$key = q/cca/;
$external_latex_labels{$key} = q|3.23|; 
$noresave{$key} = "$nosave";

$key = q/copyright/;
$external_latex_labels{$key} = q|3.1|; 
$noresave{$key} = "$nosave";

$key = q/displayinputGUI/;
$external_latex_labels{$key} = q|3.6|; 
$noresave{$key} = "$nosave";

$key = q/preprocessmenu/;
$external_latex_labels{$key} = q|3.7|; 
$noresave{$key} = "$nosave";

$key = q/displaystrfv/;
$external_latex_labels{$key} = q|3.18|; 
$noresave{$key} = "$nosave";

$key = q/strfa/;
$external_latex_labels{$key} = q|3.15|; 
$noresave{$key} = "$nosave";

$key = q/infortol/;
$external_latex_labels{$key} = q|3.25|; 
$noresave{$key} = "$nosave";

$key = q/loadstimonly/;
$external_latex_labels{$key} = q|3.28|; 
$noresave{$key} = "$nosave";

$key = q/infoa/;
$external_latex_labels{$key} = q|3.24|; 
$noresave{$key} = "$nosave";

$key = q/spectrogramfig/;
$external_latex_labels{$key} = q|3.8|; 
$noresave{$key} = "$nosave";

$key = q/displaybeststrfall/;
$external_latex_labels{$key} = q|3.27|; 
$noresave{$key} = "$nosave";

$key = q/loadfile/;
$external_latex_labels{$key} = q|3.3|; 
$noresave{$key} = "$nosave";

$key = q/calculationGUI/;
$external_latex_labels{$key} = q|3.13|; 
$noresave{$key} = "$nosave";

$key = q/displaypsth-2/;
$external_latex_labels{$key} = q|3.21|; 
$noresave{$key} = "$nosave";

$key = q/movielinear/;
$external_latex_labels{$key} = q|3.10|; 
$noresave{$key} = "$nosave";

$key = q/displayraw/;
$external_latex_labels{$key} = q|3.4|; 
$noresave{$key} = "$nosave";

$key = q/strfa_3/;
$external_latex_labels{$key} = q|3.17|; 
$noresave{$key} = "$nosave";

$key = q/displayraw2/;
$external_latex_labels{$key} = q|3.5|; 
$noresave{$key} = "$nosave";

$key = q/waveletfig/;
$external_latex_labels{$key} = q|3.9|; 
$noresave{$key} = "$nosave";

$key = q/modspectrum/;
$external_latex_labels{$key} = q|3.14|; 
$noresave{$key} = "$nosave";

$key = q/main/;
$external_latex_labels{$key} = q|3.2|; 
$noresave{$key} = "$nosave";

$key = q/askpred/;
$external_latex_labels{$key} = q|3.19|; 
$noresave{$key} = "$nosave";

$key = q/displaypreprocess/;
$external_latex_labels{$key} = q|3.12|; 
$noresave{$key} = "$nosave";

$key = q/predndisplay/;
$external_latex_labels{$key} = q|3.30|; 
$noresave{$key} = "$nosave";

$key = q/strfa_2/;
$external_latex_labels{$key} = q|3.16|; 
$noresave{$key} = "$nosave";

$key = q/moviepfft/;
$external_latex_labels{$key} = q|3.11|; 
$noresave{$key} = "$nosave";

$key = q/goodnessfilterwidth/;
$external_latex_labels{$key} = q|3.22|; 
$noresave{$key} = "$nosave";

$key = q/bestornot/;
$external_latex_labels{$key} = q|3.29|; 
$noresave{$key} = "$nosave";

$key = q/displaybeststrf/;
$external_latex_labels{$key} = q|3.26|; 
$noresave{$key} = "$nosave";

$key = q/cache/;
$external_latex_labels{$key} = q|3.31|; 
$noresave{$key} = "$nosave";

1;

