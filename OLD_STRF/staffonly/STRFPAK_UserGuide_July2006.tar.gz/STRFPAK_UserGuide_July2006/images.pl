# LaTeX2HTML 2002 (1.62)
# Associate images original text with physical files.


$key = q/includegraphics[width=5in]{figuresslashdisplaystrfv.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="394" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img73.png"
 ALT="\includegraphics[width=5in]{figures/displaystrfv.ps}">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_goodnesscc.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="574" HEIGHT="404" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img112.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_goodnesscc.ps}">|; 

$key = q/14;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img60.png"
 ALT="$14$">|; 

$key = q/95;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img110.png"
 ALT="$95$">|; 

$key = q/Tol_val;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="66" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img126.png"
 ALT="$Tol\_val$">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_goodnessinfo.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="574" HEIGHT="404" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img113.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_goodnessinfo.ps}">|; 

$key = q/10;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img90.png"
 ALT="$10$">|; 

$key = q/y-axis;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="73" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img64.png"
 ALT="$y-axis$">|; 

$key = q/cal_AutoCorr.m;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="138" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img44.png"
 ALT="$cal\_AutoCorr.m$">|; 

$key = q/includegraphics[]{figuresslashstrfpak_moviepfft.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="789" HEIGHT="658" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img35.png"
 ALT="\includegraphics[]{figures/strfpak_moviepfft.ps}">|; 

$key = q/j;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img51.png"
 ALT="$j$">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_displayraw_vision.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="422" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_displayraw_vision.ps}">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_loaddata.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="574" HEIGHT="404" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_loaddata.ps}">|; 

$key = q/Time;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="50" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="$Time$">|; 

$key = q/fbox{No};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="39" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img79.png"
 ALT="\fbox{No}">|; 

$key = q/h;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img56.png"
 ALT="$h$">|; 

$key = q/fbox{Close};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="59" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img30.png"
 ALT="\fbox{Close}">|; 

$key = q/fbox{Stop};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="53" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="\fbox{Stop}">|; 

$key = q/omega;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img98.png"
 ALT="$\omega$">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_displaybeststrfall.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="576" HEIGHT="404" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img119.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_displaybeststrfall.ps}">|; 

$key = q/fbox{ClearCache};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="115" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img131.png"
 ALT="\fbox{Clear Cache}">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_predndisplay0.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="488" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img123.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_predndisplay0.ps}">|; 

$key = q/C_{sr};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img46.png"
 ALT="$C_{sr}$">|; 

$key = q/fbox{LoadData};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="103" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img37.png"
 ALT="\fbox{Load Data}">|; 

$key = q/fbox{Next_10Trials};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="127" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="\fbox{Next\_10Trials}">|; 

$key = q/STRFPAK_batch_template.m;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="257" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img132.png"
 ALT="$STRFPAK\_batch\_template.m$">|; 

$key = q/fbox{Computegoodnessoffit};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="215" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img115.png"
 ALT="\fbox{Compute goodness of fit}">|; 

$key = q/omega_t;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img63.png"
 ALT="$\omega_t$">|; 

$key = q/<(hat{r}-r)^2>;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="108" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img54.png"
 ALT="$&lt;(\hat{r} - r)^2&gt;$">|; 

$key = q/r(t);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="35" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img101.png"
 ALT="$r(t)$">|; 

$key = q/cc_ratio;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="68" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img111.png"
 ALT="$cc\_ratio$">|; 

$key = q/fbox{Loadfiles};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="94" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img33.png"
 ALT="\fbox{Load files}">|; 

$key = q/Tol_Valu;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img71.png"
 ALT="$Tol\_Valu$">|; 

$key = q/cal_;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="35" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img43.png"
 ALT="$cal\_$">|; 

$key = q/omega_f;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img65.png"
 ALT="$\omega_f$">|; 

$key = q/21;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img108.png"
 ALT="$21$">|; 

$key = q/non-Time;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="104" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="$non-Time$">|; 

$key = q/i,j;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img57.png"
 ALT="$i,j$">|; 

$key = q/fbox{Parameters};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="108" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img41.png"
 ALT="\fbox{Parameters}">|; 

$key = q/C_{ss};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="31" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img45.png"
 ALT="$C_{ss}$">|; 

$key = q/i;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="11" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img50.png"
 ALT="$i$">|; 

$key = q/fbox{Yes};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="44" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img78.png"
 ALT="\fbox{Yes}">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_preprocessmenu.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="576" HEIGHT="404" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_preprocessmenu.ps}">|; 

$key = q/includegraphics[width=6in]{figuresslashstrfpak_mainwindow.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="689" HEIGHT="484" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="\includegraphics[width=6in]{figures/strfpak_mainwindow.ps}">|; 

$key = q/fbox{LoadPrevResult};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="159" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img127.png"
 ALT="\fbox{Load Prev Result}">|; 

$key = q/fbox{button};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\fbox{button}">|; 

$key = q/const_CC_ratio;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="132" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img105.png"
 ALT="$const\_CC\_ratio$">|; 

$key = q/j,i;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img58.png"
 ALT="$j,i$">|; 

$key = q/includegraphics[width=4in]{figuresslashstrfpak_getvalfiles.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="459" HEIGHT="323" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img74.png"
 ALT="\includegraphics[width=4in]{figures/strfpak_getvalfiles.ps}">|; 

$key = q/0.05;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img83.png"
 ALT="$0.05$">|; 

$key = q/{displaymath}h=C_{ss}^{-1}C_{sr}{displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="93" HEIGHT="33" BORDER="0"
 SRC="|."$dir".q|img55.png"
 ALT="\begin{displaymath}h = C_{ss}^{-1}C_{sr}\end{displaymath}">|; 

$key = q/x-axis;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="74" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img62.png"
 ALT="$x-axis$">|; 

$key = q/2D;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="30" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img89.png"
 ALT="$2D$">|; 

$key = q/N;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img52.png"
 ALT="$N$">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_goodnesstolstd.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="574" HEIGHT="404" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img114.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_goodnesstolstd.ps}">|; 

$key = q/fbox{ComputeandSave};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="170" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img25.png"
 ALT="\fbox{Compute and Save}">|; 

$key = q/?;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="$?$">|; 

$key = q/MATCH_FLAG;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="147" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img77.png"
 ALT="$MATCH\_FLAG$">|; 

$key = q/{displaymath}cc=frac{<(r(t)-bar{r(t)})(hat{r}(t)-bar{hat{r}(t)})>}{sqrt{<(r(t)-bar{r(t)})^2><(hat{r}(t)-bar{hat{r}(t)})^2>}}{displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="351" HEIGHT="63" BORDER="0"
 SRC="|."$dir".q|img103.png"
 ALT="\begin{displaymath}
cc = \frac{&lt;(r(t) - \bar{r(t)}) (\hat{r}(t) - \bar{\hat{r}(...
...{&lt;(r(t) - \bar{r(t)})^2&gt;&lt;(\hat{r}(t) - \bar{\hat{r}(t)})^2&gt;}}
\end{displaymath}">|; 

$key = q/DataSet;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="75" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img91.png"
 ALT="$Data Set$">|; 

$key = q/fbox{Predict};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="75" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img125.png"
 ALT="\fbox{Predict}">|; 

$key = q/includegraphics[]{figuresslashstrfpak_displaypreprocess.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="598" HEIGHT="508" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img36.png"
 ALT="\includegraphics[]{figures/strfpak_displaypreprocess.ps}">|; 

$key = q/6;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img76.png"
 ALT="$6$">|; 

$key = q/1D;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="30" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img84.png"
 ALT="$1D$">|; 

$key = q/R(omega);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="46" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img96.png"
 ALT="$R(\omega)$">|; 

$key = q/0;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="$0$">|; 

$key = q/I;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img99.png"
 ALT="$I$">|; 

$key = q/includegraphics[width=5in]{figuresslashwaveletfig.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="439" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img31.png"
 ALT="\includegraphics[width=5in]{figures/waveletfig.ps}">|; 

$key = q/5;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img75.png"
 ALT="$5$">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_displaystrf_v.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="550" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img68.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_displaystrf_v.ps}">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_predndisplay.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="488" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img124.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_predndisplay.ps}">|; 

$key = q/|FFT|^2;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="66" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="$\vert FFT\vert^2$">|; 

$key = q/72;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img59.png"
 ALT="$72$">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_goodnessfilterwidth.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="574" HEIGHT="404" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img106.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_goodnessfilterwidth.ps}">|; 

$key = q/fbox{Next};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="55" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="\fbox{Next}">|; 

$key = q/fbox{DisplaySTRFs};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="140" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img40.png"
 ALT="\fbox{Display STRFs}">|; 

$key = q/16;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img109.png"
 ALT="$16$">|; 

$key = q/cc;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img100.png"
 ALT="$cc$">|; 

$key = q/fbox{DisplayStimStat};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="156" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img39.png"
 ALT="\fbox{Display StimStat}">|; 

$key = q/max_CC_ratio;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="125" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img104.png"
 ALT="$max\_CC\_ratio$">|; 

$key = q/M;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img53.png"
 ALT="$M$">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_displaybeststrf.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="576" HEIGHT="404" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img118.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_displaybeststrf.ps}">|; 

$key = q/TolVal;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="70" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img117.png"
 ALT="$Tol Val$">|; 

$key = q/fbox{PreprocessData};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="149" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="\fbox{Preprocess Data}">|; 

$key = q/C:Temp_Cache;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="142" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img129.png"
 ALT="$C:Temp\_Cache$">|; 

$key = q/STRFPAK_core.m;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="169" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img133.png"
 ALT="$STRFPAK\_core.m$">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_displayrawdata.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="574" HEIGHT="404" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_displayrawdata.ps}">|; 

$key = q/{displaymath}C_{sr}=<sr>=left(array{{c}<s[t-0]r[t]>vdots<s[t-NM+1]r[t]>array{right){displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="348" HEIGHT="84" BORDER="0"
 SRC="|."$dir".q|img48.png"
 ALT="\begin{displaymath}C_{sr} = &lt;sr&gt; = \left(\begin{array}{c}
&lt;s[t - 0]r[t]&gt;\ \vdots \\\\
&lt;s[t-NM+1]r[t]&gt; \end{array}
\right)
\end{displaymath}">|; 

$key = q/fbox{Play};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="\fbox{Play}">|; 

$key = q/{displaymath}hat{r}[t]=sum_{i=0}^{MN-1}h[i]s_t[i]{displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="156" HEIGHT="59" BORDER="0"
 SRC="|."$dir".q|img80.png"
 ALT="\begin{displaymath}\hat{r}[t] = \sum_{i=0}^{MN-1} h[i]s_t[i]\end{displaymath}">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_cacheoption.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="446" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img128.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_cacheoption.ps}">|; 

$key = q/fbox{DisplaySTRF};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="133" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img66.png"
 ALT="\fbox{Display STRF}">|; 

$key = q/Tol_Val;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img69.png"
 ALT="$Tol\_Val$">|; 

$key = q/fbox{CalculationAlgorithm};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="199" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img42.png"
 ALT="\fbox{Calculation Algorithm}">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_displayinputGUI.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="488" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_displayinputGUI.ps}">|; 

$key = q/fbox{WaveletTransform};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="171" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img32.png"
 ALT="\fbox{Wavelet Transform}">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_songwavespectrum.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="488" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_songwavespectrum.ps}">|; 

$key = q/http:slashslashneuralprediction.berkeley.edu;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="321" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img122.png"
 ALT="$http://neuralprediction.berkeley.edu$">|; 

$key = q/fbox{Help};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="53" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\fbox{Help}">|; 

$key = q/{displaymath}gamma^2(omega)=frac{<R(omega)hat{R}(omega)^{*}><R(omega)^{*}hat{R}(a)R(omega)^{*}><hat{R}(omega)hat{R}(omega)^{*}>}{displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="332" HEIGHT="58" BORDER="0"
 SRC="|."$dir".q|img95.png"
 ALT="\begin{displaymath}
\gamma^2(\omega) = \frac{&lt;R(\omega) \hat{R}(\omega)^{*}&gt;&lt;R(...
...(\omega) R(\omega)^{*}&gt;&lt;\hat{R}(\omega) \hat{R}(\omega)^{*}&gt;}
\end{displaymath}">|; 

$key = q/s_t[i];MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img82.png"
 ALT="$s_t[i]$">|; 

$key = q/h[i]=[h_0,...,h_{NM-1}]^T;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="184" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img81.png"
 ALT="$h[i]=[h_0,...,h_{NM-1}]^T$">|; 

$key = q/y;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img87.png"
 ALT="$y$">|; 

$key = q/includegraphics[width=5in]{figuresslashdisplaypredv.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="536" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img93.png"
 ALT="\includegraphics[width=5in]{figures/displaypredv.ps}">|; 

$key = q/rightarrow;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$\rightarrow $">|; 

$key = q/includegraphics[]{figuresslashstrfpak_calculationGUI.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="724" HEIGHT="651" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img38.png"
 ALT="\includegraphics[]{figures/strfpak_calculationGUI.ps}">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfa_3.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="556" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img72.png"
 ALT="\includegraphics[width=5in]{figures/strfa_3.ps}">|; 

$key = q/hat{R}(omega);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="46" HEIGHT="44" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img97.png"
 ALT="$\hat{R}(\omega)$">|; 

$key = q/fbox{Prev_10Trials};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="126" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="\fbox{Prev\_10Trials}">|; 

$key = q/100;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="33" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img107.png"
 ALT="$100$">|; 

$key = q/x;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img85.png"
 ALT="$x$">|; 

$key = q/fbox{SelectData};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="110" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="\fbox{Select Data}">|; 

$key = q/msec;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="47" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img86.png"
 ALT="$msec$">|; 

$key = q/fbox{SmoothPSTH};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="135" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img28.png"
 ALT="\fbox{Smooth PSTH}">|; 

$key = q/c_{i,j};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img49.png"
 ALT="$c_{i,j}$">|; 

$key = q/{displaymath}C_{ss}=left(array{{ccc}c_{0,0}&cdots&c_{0,M-1}vdots&ddots&vdotsc_{M-1,0}&cdots&c_{M-1,M-1}array{right){displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="272" HEIGHT="84" BORDER="0"
 SRC="|."$dir".q|img47.png"
 ALT="\begin{displaymath}C_{ss} = \left( \begin{array}{ccc}
c_{0,0} &amp; \cdots &amp; c_{0,...
...\
c_{M-1, 0} &amp; \cdots &amp; c_{M-1, M-1}
\end{array} \right)
\end{displaymath}">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_copyright.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="370" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_copyright.ps}">|; 

$key = q/1;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img130.png"
 ALT="$1$">|; 

$key = q/includegraphics[width=5in]{figuresslashmodspectrum.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="576" HEIGHT="502" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img61.png"
 ALT="\includegraphics[width=5in]{figures/modspectrum.ps}">|; 

$key = q/fbox{Goodnessoffitting};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="171" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img94.png"
 ALT="\fbox{Goodness of fitting}">|; 

$key = q/fbox{Display};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="77" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img24.png"
 ALT="\fbox{Display}">|; 

$key = q/Sparseness;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="100" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img70.png"
 ALT="$Sparseness$">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_loadstimonly.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="488" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img121.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_loadstimonly.ps}">|; 

$key = q/Hz;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="31" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img88.png"
 ALT="$Hz$">|; 

$key = q/fbox{Prev};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="54" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img27.png"
 ALT="\fbox{Prev}">|; 

$key = q/hat{r}(t);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="35" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img102.png"
 ALT="$\hat{r}(t)$">|; 

$key = q/fbox{OutputDir};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="109" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img29.png"
 ALT="\fbox{ OutputDir}">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_displaypredpsth.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="575" HEIGHT="488" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img92.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_displaypredpsth.ps}">|; 

$key = q/fbox{ShortTimeFourierTransform};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="264" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img23.png"
 ALT="\fbox{Short Time Fourier Transform}">|; 

$key = q/fbox{DisplayBestStrf};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="150" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img120.png"
 ALT="\fbox{Display BestStrf}">|; 

$key = q/r;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img116.png"
 ALT="$r$">|; 

$key = q/includegraphics[]{figuresslashstrfpak_movielinear.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="863" HEIGHT="724" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img34.png"
 ALT="\includegraphics[]{figures/strfpak_movielinear.ps}">|; 

$key = q/includegraphics[width=5in]{figuresslashstrfpak_displaystrf.ps};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="576" HEIGHT="489" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img67.png"
 ALT="\includegraphics[width=5in]{figures/strfpak_displaystrf.ps}">|; 

1;

