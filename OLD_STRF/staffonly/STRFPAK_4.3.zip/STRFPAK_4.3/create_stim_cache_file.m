function hashes_of_stims = create_stim_cache_file(outputPath,DS);
%  Creates the file with the hashes of the stimuli
hashes_of_stims = {};
for ii = 1:length(DS)
    hashes_of_stims{ii} = checksum(checksum_from_file(DS{ii}.respfiles),DS{ii}.ntrials),
end
save(fullfile(outputPath,'preprocessed_stim_hashes.mat'),'hashes_of_stims');
