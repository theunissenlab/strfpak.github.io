function hashes_of_spikes = create_spike_cache_file(outputPath,DS);
%  Creates the file with the hashes of the stimuli
hashes_of_spikes = {};
for ii = 1:length(DS)
    hashes_of_spikes{ii} = checksum(checksum_from_file(DS{ii}.respfiles),DS{ii}.ntrials);
end
save(fullfile(outputPath,'hashes_of_spikes.mat'),'hashes_of_spikes');
