function out = checksum_from_file(filename);
%  Produces a checksum from a file that's already there.

fid = fopen(filename);
input = fread(fid,inf,'uint8');
fclose(fid);
input = uint8(input(120:end));   %  Remove the date stamp in the file; we don't want our hashes to depend on that!
filter = [ones(16,1) ; -1*ones(16,1)];

the_conv = conv(filter,double(input));

out =[];
for jj = 1:16
    toadd = mod(sum(the_conv(jj:32:end)),256);
    out = [out dec2hex(toadd,2)];
end
