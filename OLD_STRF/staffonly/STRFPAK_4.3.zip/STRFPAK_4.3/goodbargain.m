function out = goodbargain(a)
pause(5);
out = 1;