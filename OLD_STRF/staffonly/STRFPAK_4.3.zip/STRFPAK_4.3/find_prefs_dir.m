function outdir = find_prefs_dir
%  Returns the directory where your preferences are to be stored.  Will use
%  the same directory as dir_of_caches.
outdir = which('dir_of_caches.m');
slashes = strfind(outdir,filesep);
outdir = outdir(1:slashes(end));