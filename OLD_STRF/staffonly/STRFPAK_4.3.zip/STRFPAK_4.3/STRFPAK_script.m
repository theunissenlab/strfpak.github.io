%  Hello and welcome to STRFPAK_script.  This file is a collection of
%  commands which mirror the instructions performed by the gui version of
%  STRFPAK for the cell in this output directory.
%  This code is dynamically generated as you click through STRFPAK.  
%
%  As of version 4.1, this code looks for two .mat files:
%  STRFPAK_script_parameters.mat and STRFPAK_script_dataset.mat.  The first
%  contains all your options and settings; the second contains the file
%  names of your input datasets and everything specific to that one cell.  
%  We hope it will be easy to "hack" STRFPAK_script_dataset.mat so that 
%  you can do computations for other cells and datasets without having to 
%  run the gui version of STRFPAK each time.  Good luck!

load STRFPAK_script_parameters.mat %contains all your tol values, smoothing windows, etc.
load STRFPAK_script_dataset.mat %everything specific to the cell in question: filenames of datasets and the output directory.

%%%^^^ begin preprocess
%%%^^^ end preprocess

%%%^^^ begin calculate
%%%^^^ end calculate

%%%^^^ begin select_validation
%%%^^^ end select_validation

%%%^^^ begin goodness_of_fit
%%%^^^ end goodness_of_fit

%%%^^^ begin prediction
%%%^^^ end prediction


