function [out,order] = load_and_sort_stim_caches(hash_cache_filename);
load(hash_cache_filename);  %  Puts "hashes_of_stims" into workspace
[out,order] = sort(hashes_of_stims);
