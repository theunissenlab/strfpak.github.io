% ===========================================
% matlab script file for calStrf
% ===========================================
% Load up all files and Display for checking
% still need to look at .rec files for checking consistency
%             STRFPAK: STRF Estimation Software
% Copyright �2003. The Regents of the University of California (Regents).
% All Rights Reserved.
% Created by Theunissen Lab and Gallant Lab, Department of Psychology, Un
% -iversity of California, Berkeley.
%
% Permission to use, copy, and modify this software and its documentation
% for educational, research, and not-for-profit purposes, without fee and
% without a signed licensing agreement, is hereby granted, provided that
% the above copyright notice, this paragraph and the following two paragr
% -aphs appear in all copies and modifications. Contact The Office of Tec
% -hnology Licensing, UC Berkeley, 2150 Shattuck Avenue, Suite 510,
% Berkeley, CA 94720-1620, (510) 643-7201, for commercial licensing
% opportunities.
%
%IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
%SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
%ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
%REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
%
%REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
%LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
%PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF ANY,
%PROVIDED HEREUNDER IS PROVIDED "AS IS". REGENTS HAS NO OBLIGATION TO PRO
%-VIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
%

nstd_val = 0.5;

% ===========================================
% FFT Auto-correlation and Cross-correlation
% ===========================================

pack;
 
[fstim, fstim_spike, stim_spike_JNf] = fft_AutoCrossCorr(CS,...
   CSR,CSR_JN, round(TimeLag*ampsamprate/1000), NBAND, nstd_val);
disp('Done fft_AutoCrossCorr.');

% clear some memory
clear CSR CSR_JN CS

pack;
% ===========================================
%  Prepare for call STRF_calculation
% ===========================================
nb = NBAND;
global TimeLagUnit
if strcmp(TimeLagUnit, 'msec')
    nt = 2*round(TimeLag*ampsamprate/1000) +1;
else
    nt = 2*round(TimeLag) +1;
end
nJN = length(DS);
stim_size = size(fstim);
stim_spike_size = size(fstim_spike);
stim_spike_JNsize = size(stim_spike_JNf);


% ===========================================
% Get tolerance values
% ===========================================
global Tol_val 
ntols = length(Tol_val);
global outputPath
if isempty(outputPath)

    disp('Saving output to Output Dir.');
    stat = mkdir('Output');
    outputPath = fullfile(pwd, 'Output'); 
end
    
% ===========================================
tempWait = waitbar(0, 'Calculating STRF for each tol values...');
for itol=1:ntols
    tol=Tol_val(itol);
    
    fprintf('Now calculating STRF for tol_value: %g\n', tol);
    
    waitbar(itol/ntols, tempWait);

    % ======================================= 
    % Calculate strf for each tol val.        
    % ======================================= 
    [STRF_Cell, STRFJN_Cell, STRFJNstd_Cell] = cal_Strf(fstim,...
       fstim_spike, stim_spike_JNf,stim_size, stim_spike_size,...
       stim_spike_JNsize, nb, nt, nJN, tol);
  
    fprintf('Done calculation of  STRF for tol_value: %g\n', tol);


    sfilename = sprintf('strfResult_Tol%d.mat',itol); 
    save(fullfile(outputPath,sfilename), 'STRF_Cell', 'STRFJN_Cell', 'STRFJNstd_Cell');

    clear STRF_Cell STRFJN_Cell STRFJNstd_Cell 
end

close(tempWait)

% ===========================================
%  END of calStrf_script.m
% ===========================================

